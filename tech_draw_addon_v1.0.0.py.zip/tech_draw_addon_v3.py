bl_info = {
    "name": "Tech Draw",
    "author": "butterfiled",
    "version": (1, 0, 2),
    "blender": (3, 0, 0),
    "location": "3D Viewport > N-Panel > Tech Draw",
    "description": "SolidWorks style technical drawing tools: ortho/iso views, line rendering, dimension labels",
    "category": "3D View",
}

import bpy
import bmesh
import math
from mathutils import Vector, Matrix, Euler

DIM_COLLECTION = "TechDraw_Dimensions"


class TechDrawSettings(bpy.types.PropertyGroup):
    text_size: bpy.props.FloatProperty(
        name="Text Size",
        description="Height of dimension text (in scene units)",
        default=0.08, min=0.001, soft_max=10.0,
    )
    decimals: bpy.props.IntProperty(
        name="Decimals",
        description="Decimal places shown on dimensions",
        default=1, min=0, max=6,
    )
    unit_scale: bpy.props.FloatProperty(
        name="Unit Scale",
        description="Multiplier applied to measured distance (e.g. 1000 to show metres as mm)",
        default=1000.0, min=0.000001,
    )
    unit_suffix: bpy.props.StringProperty(
        name="Suffix",
        description="Unit label appended to the number",
        default="mm",
    )
    offset: bpy.props.FloatProperty(
        name="Offset",
        description="Distance the dimension line sits away from the measured edge",
        default=0.25, min=0.0, soft_max=10.0,
    )
    arrow_size: bpy.props.FloatProperty(
        name="Arrow Size",
        description="Length of the arrowheads",
        default=0.06, min=0.001, soft_max=1.0,
    )
    line_thickness: bpy.props.IntProperty(
        name="Line Art Thickness",
        description="Stroke thickness for the Line Art object",
        default=2, min=1, max=20,
    )



def get_view3d_region_data(context):
    """Return the RegionView3D of the active/first 3D viewport."""
    if context.space_data and context.space_data.type == 'VIEW_3D':
        return context.space_data.region_3d
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    return space.region_3d
    return None


def get_dim_collection(context):
    coll = bpy.data.collections.get(DIM_COLLECTION)
    if coll is None:
        coll = bpy.data.collections.new(DIM_COLLECTION)
        context.scene.collection.children.link(coll)
    elif coll.name not in {c.name for c in context.scene.collection.children_recursive}:
        try:
            context.scene.collection.children.link(coll)
        except RuntimeError:
            pass  
    return coll


def selected_measure_points(context):
    """Return two world-space points from the current selection, or None.

    Edit Mode: exactly 2 selected vertices.
    Object Mode: exactly 2 selected objects (their origins).
    """
    obj = context.active_object
    if obj and obj.mode == 'EDIT' and obj.type == 'MESH':
        bm = bmesh.from_edit_mesh(obj.data)
        verts = [v for v in bm.verts if v.select]
        if len(verts) == 2:
            mw = obj.matrix_world
            return mw @ verts[0].co, mw @ verts[1].co
        return None
    sel = context.selected_objects
    if len(sel) == 2:
        return sel[0].matrix_world.translation.copy(), sel[1].matrix_world.translation.copy()
    return None


def make_poly_curve(name, segments):
    """Build a curve object from a list of point-lists (each a poly spline)."""
    curve_data = bpy.data.curves.new(name, type='CURVE')
    curve_data.dimensions = '3D'
    for pts in segments:
        spline = curve_data.splines.new('POLY')
        spline.points.add(len(pts) - 1)
        for sp_pt, co in zip(spline.points, pts):
            sp_pt.co = (co.x, co.y, co.z, 1.0)
    return bpy.data.objects.new(name, curve_data)


def format_distance(settings, dist):
    value = dist * settings.unit_scale
    txt = f"{value:.{settings.decimals}f}"
    if settings.unit_suffix:
        txt += f" {settings.unit_suffix}"
    return txt



VIEW_ITEMS = [
    ('FRONT', "Front", ""), ('BACK', "Back", ""),
    ('LEFT', "Left", ""), ('RIGHT', "Right", ""),
    ('TOP', "Top", ""), ('BOTTOM', "Bottom", ""),
]

ISO_ITEMS = [
    ('NE', "Iso NE", ""), ('NW', "Iso NW", ""),
    ('SE', "Iso SE", ""), ('SW', "Iso SW", ""),
]


class TECHDRAW_OT_set_view(bpy.types.Operator):
    """Snap the viewport to an orthographic standard view"""
    bl_idname = "techdraw.set_view"
    bl_label = "Set Orthographic View"
    bl_options = {'REGISTER', 'UNDO'}

    view: bpy.props.EnumProperty(items=VIEW_ITEMS)

    def execute(self, context):
        rv3d = get_view3d_region_data(context)
        if rv3d is None:
            self.report({'ERROR'}, "No 3D viewport found")
            return {'CANCELLED'}
        bpy.ops.view3d.view_axis(type=self.view)
        rv3d.view_perspective = 'ORTHO'
        return {'FINISHED'}


class TECHDRAW_OT_set_iso(bpy.types.Operator):
    """Snap the viewport to a true isometric view (orthographic)"""
    bl_idname = "techdraw.set_iso"
    bl_label = "Set Isometric View"
    bl_options = {'REGISTER', 'UNDO'}

    corner: bpy.props.EnumProperty(items=ISO_ITEMS, default='NE')

    def execute(self, context):
        rv3d = get_view3d_region_data(context)
        if rv3d is None:
            self.report({'ERROR'}, "No 3D viewport found")
            return {'CANCELLED'}
        tilt = math.radians(54.7356)
        z_map = {'NE': 45.0, 'NW': 135.0, 'SW': 225.0, 'SE': 315.0}
        eul = Euler((tilt, 0.0, math.radians(z_map[self.corner])), 'XYZ')
        rv3d.view_rotation = eul.to_quaternion()
        rv3d.view_perspective = 'ORTHO'
        return {'FINISHED'}


class TECHDRAW_OT_drawing_shading(bpy.types.Operator):
    """Set the viewport to a flat white 'technical drawing' look with visible edges"""
    bl_idname = "techdraw.drawing_shading"
    bl_label = "Drawing Shading"
    bl_options = {'REGISTER', 'UNDO'}

    enable: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        for area in context.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for space in area.spaces:
                if space.type != 'VIEW_3D':
                    continue
                sh = space.shading
                ov = space.overlay
                if self.enable:
                    sh.type = 'SOLID'
                    sh.light = 'FLAT'
                    sh.color_type = 'SINGLE'
                    sh.single_color = (1.0, 1.0, 1.0)
                    sh.show_object_outline = True
                    sh.show_shadows = False
                    sh.show_cavity = False
                    ov.show_wireframes = True
                    ov.wireframe_threshold = 0.8  
                    try:
                        ov.wireframe_opacity = 1.0
                    except AttributeError:
                        pass
                    ov.show_floor = False
                    ov.show_axis_x = False
                    ov.show_axis_y = False
                else:
                    sh.light = 'STUDIO'
                    sh.color_type = 'MATERIAL'
                    ov.show_wireframes = False
                    ov.show_floor = True
                    ov.show_axis_x = True
                    ov.show_axis_y = True
        return {'FINISHED'}



class TECHDRAW_OT_add_lineart(bpy.types.Operator):
    """Add a Grease Pencil Line Art object that traces the whole scene as lines"""
    bl_idname = "techdraw.add_lineart"
    bl_label = "Add Scene Line Art"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.techdraw_settings
        created = False
        try:
            bpy.ops.object.gpencil_add(type='LRT_SCENE')
            created = True
        except (AttributeError, TypeError, RuntimeError):
            pass
        if not created:
            try:
                bpy.ops.object.grease_pencil_add(type='LINEART_SCENE')
                created = True
            except (AttributeError, TypeError, RuntimeError):
                pass
        if not created:
            self.report({'ERROR'}, "Could not create a Line Art object in this Blender version")
            return {'CANCELLED'}

        gp = context.active_object
        gp.name = "TechDraw_LineArt"
        for mod in getattr(gp, "grease_pencil_modifiers", []):
            if mod.type == 'GP_LINEART':
                mod.thickness = settings.line_thickness
        for mod in getattr(gp, "modifiers", []):
            if getattr(mod, "type", "") in {'LINEART', 'GREASE_PENCIL_LINEART'}:
                try:
                    mod.thickness = settings.line_thickness
                except AttributeError:
                    pass
        self.report({'INFO'}, "Line Art added — it bakes edges of everything in the scene")
        return {'FINISHED'}



class TECHDRAW_OT_add_dimension(bpy.types.Operator):
    """Add a linear dimension between 2 selected vertices (Edit Mode) or 2 objects (Object Mode)"""
    bl_idname = "techdraw.add_dimension"
    bl_label = "Add Dimension"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.techdraw_settings
        points = selected_measure_points(context)
        if points is None:
            self.report({'ERROR'},
                        "Select exactly 2 vertices (Edit Mode) or 2 objects (Object Mode)")
            return {'CANCELLED'}
        p1, p2 = points
        dist = (p2 - p1).length
        if dist < 1e-9:
            self.report({'ERROR'}, "Points are coincident")
            return {'CANCELLED'}

        rv3d = get_view3d_region_data(context)
        view_normal = (rv3d.view_rotation @ Vector((0, 0, 1))) if rv3d else Vector((0, 0, 1))

        d = (p2 - p1).normalized()
        perp = d.cross(view_normal)
        if perp.length < 1e-6:
            perp = d.cross(Vector((0, 0, 1)))
            if perp.length < 1e-6:
                perp = d.cross(Vector((0, 1, 0)))
        perp.normalize()


        if rv3d:
            view_up = rv3d.view_rotation @ Vector((0, 1, 0))
            view_right = rv3d.view_rotation @ Vector((1, 0, 0))
            if abs(perp.dot(view_up)) > 1e-4:
                if perp.dot(view_up) < 0:
                    perp = -perp
            elif perp.dot(view_right) < 0:
                perp = -perp

        off = settings.offset
        a = settings.arrow_size
        overshoot = a * 0.6

        q1 = p1 + perp * off
        q2 = p2 + perp * off

        segments = []
        gap = a * 0.4
        segments.append([p1 + perp * gap, q1 + perp * overshoot])
        segments.append([p2 + perp * gap, q2 + perp * overshoot])
        segments.append([q1, q2])
        w = a * 0.35
        segments.append([q1 + d * a + perp * w, q1, q1 + d * a - perp * w])
        segments.append([q2 - d * a + perp * w, q2, q2 - d * a - perp * w])

        coll = get_dim_collection(context)

        lines = make_poly_curve("Dim_Lines", segments)
        coll.objects.link(lines)
        lines.show_in_front = True

        txt_data = bpy.data.curves.new("Dim_Text", type='FONT')
        txt_data.body = format_distance(settings, dist)
        txt_data.size = settings.text_size
        txt_data.align_x = 'CENTER'
        txt_data.align_y = 'BOTTOM'
        txt = bpy.data.objects.new("Dim_Text", txt_data)
        coll.objects.link(txt)
        txt.show_in_front = True

        n = view_normal.normalized()  
        x_axis = d - d.dot(n) * n
        if x_axis.length < 1e-6:
            x_axis = perp.cross(n)
        x_axis.normalize()
        if rv3d:
            view_right = rv3d.view_rotation @ Vector((1, 0, 0))
            if x_axis.dot(view_right) < 0:
                x_axis = -x_axis
        y_axis = n.cross(x_axis)  
        rot = Matrix((x_axis, y_axis, n)).transposed().to_4x4()

        mid_line = (q1 + q2) * 0.5
        text_pos = mid_line + y_axis * (a * 0.4)
        txt.matrix_world = Matrix.Translation(text_pos) @ rot

        root = bpy.data.objects.new("Dimension", None)
        root.empty_display_size = 0.01
        coll.objects.link(root)
        root_mat = Matrix.Translation(mid_line)
        root.matrix_world = root_mat

        inv = root_mat.inverted()
        for child in (lines, txt):
            child.parent = root
            child.matrix_parent_inverse = inv

        self.report({'INFO'}, f"Dimension: {txt_data.body}")
        return {'FINISHED'}


class TECHDRAW_OT_clear_dimensions(bpy.types.Operator):
    """Delete all TechDraw dimensions"""
    bl_idname = "techdraw.clear_dimensions"
    bl_label = "Clear All Dimensions"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        coll = bpy.data.collections.get(DIM_COLLECTION)
        if coll:
            for obj in list(coll.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(coll)
        return {'FINISHED'}




def get_techdraw_camera(context):
    """Return the (single) TechDraw camera, creating it if needed."""
    cam = bpy.data.objects.get("TechDraw_Camera")
    if cam is None or cam.type != 'CAMERA':
        cam_data = bpy.data.cameras.new("TechDraw_Camera")
        cam = bpy.data.objects.new("TechDraw_Camera", cam_data)
    if cam.name not in context.scene.collection.all_objects:
        context.scene.collection.objects.link(cam)
    return cam


def align_camera_to_view(context, cam):
    """Point the camera through the current viewport view (ortho or persp)."""
    rv3d = get_view3d_region_data(context)
    space = context.space_data if (context.space_data and context.space_data.type == 'VIEW_3D') else None
    if rv3d is None:
        return False
    if rv3d.view_perspective == 'CAMERA':
        return True  # already looking through a camera; keep its framing
    cam.data.type = 'ORTHO' if rv3d.view_perspective == 'ORTHO' else 'PERSP'
    context.scene.camera = cam
    try:
        bpy.ops.view3d.camera_to_view()
    except RuntimeError:
        cam.matrix_world = rv3d.view_matrix.inverted()
        if cam.data.type == 'ORTHO':
            lens = space.lens if space else 50.0
            cam.data.ortho_scale = rv3d.view_distance * 36.0 / lens
    return True


class TECHDRAW_OT_camera_from_view(bpy.types.Operator):
    """Create/update the TechDraw orthographic camera to match the current viewport view"""
    bl_idname = "techdraw.camera_from_view"
    bl_label = "Ortho Camera From View"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cam = get_techdraw_camera(context)
        if not align_camera_to_view(context, cam):
            self.report({'ERROR'}, "No 3D viewport found")
            return {'CANCELLED'}
        return {'FINISHED'}


class TECHDRAW_OT_render_view(bpy.types.Operator):
    """Snap the TechDraw camera to the current view and render it"""
    bl_idname = "techdraw.render_view"
    bl_label = "Render Current View"

    def execute(self, context):
        cam = get_techdraw_camera(context)
        if not align_camera_to_view(context, cam):
            self.report({'ERROR'}, "No 3D viewport found")
            return {'CANCELLED'}
        bpy.ops.render.render('INVOKE_DEFAULT')
        return {'FINISHED'}


class TECHDRAW_OT_setup_freestyle(bpy.types.Operator):
    """Configure the render for clean black-line output on white (Freestyle)"""
    bl_idname = "techdraw.setup_freestyle"
    bl_label = "Setup Line Render (Freestyle)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        for engine in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
            try:
                scene.render.engine = engine
                break
            except TypeError:
                continue
        scene.render.use_freestyle = True
        scene.render.line_thickness = 1.5
        vl = context.view_layer
        vl.use_freestyle = True

        fs = vl.freestyle_settings
        fs.crease_angle = math.radians(160.0)  # generous: catches soft/bevelled edges too
        ls = fs.linesets.active if fs.linesets else None
        if ls is None:
            ls = fs.linesets.new("TechDraw Lines")
        ls.select_silhouette = True
        ls.select_crease = True
        ls.select_border = True
        ls.select_edge_mark = True
        ls.select_contour = True
        ls.select_external_contour = True
        ls.select_material_boundary = True

        # white world
        world = scene.world or bpy.data.worlds.new("TechDraw_World")
        scene.world = world
        world.use_nodes = True
        bg = world.node_tree.nodes.get("Background")
        if bg:
            bg.inputs[0].default_value = (1, 1, 1, 1)
            bg.inputs[1].default_value = 1.0

        scene.render.film_transparent = False
        self.report({'INFO'}, "Freestyle enabled — render (F12) for a line drawing")
        return {'FINISHED'}




class TECHDRAW_PT_main(bpy.types.Panel):
    bl_label = "Tech Draw"
    bl_idname = "TECHDRAW_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tech Draw"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.techdraw_settings


        box = layout.box()
        box.label(text="Views", icon='VIEW_ORTHO')
        grid = box.grid_flow(columns=2, align=True)
        for key, label, _ in VIEW_ITEMS:
            grid.operator("techdraw.set_view", text=label).view = key
        grid2 = box.grid_flow(columns=2, align=True)
        for key, label, _ in ISO_ITEMS:
            grid2.operator("techdraw.set_iso", text=label).corner = key


        box = layout.box()
        box.label(text="Line Display", icon='MOD_LINEART')
        row = box.row(align=True)
        row.operator("techdraw.drawing_shading", text="Drawing Look", icon='SHADING_WIRE').enable = True
        row.operator("techdraw.drawing_shading", text="Restore", icon='LOOP_BACK').enable = False
        box.prop(settings, "line_thickness")
        box.operator("techdraw.add_lineart", icon='GREASEPENCIL')


        box = layout.box()
        box.label(text="Dimensions", icon='DRIVER_DISTANCE')
        col = box.column(align=True)
        col.prop(settings, "unit_scale")
        col.prop(settings, "unit_suffix")
        col.prop(settings, "decimals")
        col.separator()
        col.prop(settings, "text_size")
        col.prop(settings, "offset")
        col.prop(settings, "arrow_size")
        box.operator("techdraw.add_dimension", icon='ADD')
        box.operator("techdraw.clear_dimensions", icon='TRASH')


        box = layout.box()
        box.label(text="Output", icon='RENDER_STILL')
        box.operator("techdraw.camera_from_view", icon='CAMERA_DATA')
        box.operator("techdraw.setup_freestyle", icon='LINE_DATA')
        box.operator("techdraw.render_view", icon='RESTRICT_RENDER_OFF')



classes = (
    TechDrawSettings,
    TECHDRAW_OT_set_view,
    TECHDRAW_OT_set_iso,
    TECHDRAW_OT_drawing_shading,
    TECHDRAW_OT_add_lineart,
    TECHDRAW_OT_add_dimension,
    TECHDRAW_OT_clear_dimensions,
    TECHDRAW_OT_camera_from_view,
    TECHDRAW_OT_render_view,
    TECHDRAW_OT_setup_freestyle,
    TECHDRAW_PT_main,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.techdraw_settings = bpy.props.PointerProperty(type=TechDrawSettings)


def unregister():
    del bpy.types.Scene.techdraw_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
